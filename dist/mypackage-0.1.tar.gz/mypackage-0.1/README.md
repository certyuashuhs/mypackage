# mypackage
Some program doing something awesome

# How to install
Simple enough, just follow the guidelines